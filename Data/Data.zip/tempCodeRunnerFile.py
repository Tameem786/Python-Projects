for i in range(len(df_domain['Domain'])):
#     domains.append(df_domain['Domain'][i])